aws ssm get-parameter --name "/database/GameDay/endpoint"  --region eu-central-1 --with-decryption
aws ssm get-parameter --name "/database/GameDay/name"  --region eu-central-1 --with-decryption
aws ssm get-parameter --name "/database/GameDay/password"  --region eu-central-1 --with-decryption
aws ssm get-parameter --name "/database/GameDay/user"  --region eu-central-1 --with-decryption